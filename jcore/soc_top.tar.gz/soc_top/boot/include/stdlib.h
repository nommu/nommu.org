extern unsigned int sleep(unsigned int);
extern void usleep(unsigned int);
