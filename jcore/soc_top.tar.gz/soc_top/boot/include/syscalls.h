#ifndef __GDBSTUB_UNISTD_H__
#define __GDBSTUB_UNISTD_H__

#define __NR_open                 1
#define __NR_close                2
#define __NR_read                 3
#define __NR_write                4
#define __NR_lseek                5

#define __NR_syscalls             5

#endif /* __GDBSTUB_UNISTD_H__ */
