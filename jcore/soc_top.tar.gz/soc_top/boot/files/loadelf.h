#ifndef LOADELF_H
#define LOADELF_H

int loadelf_load(char *ch);

#endif
