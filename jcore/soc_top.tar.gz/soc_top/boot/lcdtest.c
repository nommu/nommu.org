void
grlcd(void);

int main() {
  grlcd();
  return 0;
}
