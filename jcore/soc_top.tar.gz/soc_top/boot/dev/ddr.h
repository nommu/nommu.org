#ifndef DEV_DDR_H
#define DEV_DDR_H

int ddr_init(void);

#endif
